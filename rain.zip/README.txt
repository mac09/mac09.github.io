A Pen created at CodePen.io. You can find this one at http://codepen.io/natewiley/pen/EGyiF.

 Use the `Left` and `Right` Arrows or `A` and `D` keys to move, `Spacebar` to shoot.

Game starts right away, looks best in [full mode.](http://codepen.io/natewiley/full/EGyiF) 

Hope you like it! ;)